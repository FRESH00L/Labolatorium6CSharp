﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Towary;

namespace Labolatorium6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        /////////////////////////////////// ZADANIE A///////////////////////////////////////////////
        public (double, double, double) ZnajdzMinumunFunkcji(double minX, double maxX, double minY, double maxY, int iter, Func<double, double, double> func)
        {
            Random rand = new Random();

            double? bestX = null;
            double? bestY = null;
            double? wartosc = null;

            for (int i = 0; i < iter; i++)
            {
                double x = rand.NextDouble() * (maxX - minX) + minX;
                double y = rand.NextDouble() * (maxY - minY) + minY;
                double f = func(x, y);

                if (wartosc == null || f < wartosc)
                {
                    wartosc = f;
                    bestX = x;
                    bestY = y;
                }
            }
            (double, double, double) wynik;
            wynik.Item1 = (double)bestX;
            wynik.Item2 = (double)bestY;
            wynik.Item3 = (double)wartosc;
            return wynik;
        }

        private void btn_funkcja1_Click(object sender, RoutedEventArgs e)
        {
            double x;
            double y;

            double funkcjaRosenbroka(double x, double y)
            {
                return Math.Pow((1 - x), 2) + 100 * Math.Pow((y - x * x), 2);
            }
            var wynik = this.ZnajdzMinumunFunkcji(-2, 2, -1, 3, 10000000, funkcjaRosenbroka);
            lbl_wynik.Content = $"X:{wynik.Item1},\nY:{wynik.Item2},\nwartość:{wynik.Item3}";
        }

        /////////////////////////////////// ZADANIE B ///////////////////////////////////////////////
            List<Towar> lista = new List<Towar>()
        {
            new Towar(){ Nazwa = "Sok", Cena = 2.99, Ilosc = 100, Kategoria = kategoria.napoj},
            new Towar(){ Nazwa = "Cola", Cena = 6.99, Ilosc = 25, Kategoria = kategoria.napoj},
            new Towar(){ Nazwa = "Woda", Cena = 1.99, Ilosc = 46, Kategoria = kategoria.napoj},
            new Towar(){ Nazwa = "Piwo", Cena = 4.99, Ilosc = 60, Kategoria = kategoria.napoj},
            new Towar(){ Nazwa = "Chleb", Cena = 5.99, Ilosc = 10, Kategoria = kategoria.jedzenie},
            new Towar(){ Nazwa = "Chipsy", Cena = 10.99, Ilosc = 100, Kategoria = kategoria.jedzenie},
            new Towar(){ Nazwa = "Paczek", Cena = 0.99, Ilosc = 20, Kategoria = kategoria.jedzenie},
            new Towar(){ Nazwa = "Curry", Cena = 0.99, Ilosc = 15, Kategoria = kategoria.przyprawa},
            new Towar(){ Nazwa = "Pieprz", Cena = 1.99, Ilosc = 20, Kategoria = kategoria.przyprawa},
            new Towar(){ Nazwa = "Sól", Cena = 1.99, Ilosc = 25, Kategoria = kategoria.przyprawa}
        };

        private void btn_TowaryOdIlosci5_Click(object sender, RoutedEventArgs e)
        {
            List<Towar> lista= new List<Towar>();

        }
    }


}
