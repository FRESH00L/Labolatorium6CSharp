﻿namespace Towary
{
    public enum kategoria
    {
        napoj, jedzenie, przyprawa
    };
    public class Towar
    {   
            public string Nazwa
            {
                get; set;
            }
            public double Cena
            {
                get; set;
            }
            public int Ilosc
            {
                get; set;
            }
            public kategoria Kategoria
            {
                get; set;
            }
            public String ToString()
            {
                return $"Nazwa: {Nazwa}, Cena: {Cena}, Ilość: {Ilosc}, Kategotia: {Kategoria}";
            }
        }
    }
}